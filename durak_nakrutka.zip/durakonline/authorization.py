import base64
import hashlib
from datetime import datetime
from .utils import objects


class Authorization:

    def __init__(self, client) -> None:
        self.client = client

    def get_session_key(self) -> objects.GetSessionKey:
        data = {
            "command": "c",
            "l": "ru",
            "tz": "+03:00",
            "t": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]+"Z",
            "pl": self.client.pl,
            "p": 13,
        }
        if self.client.pl == "ios":
            data.update({
                "v": "1.9.5",
                "ios": "14.4",
                "d": "iPhone8,4",
                "n": "durak.ios",
            })
        else:
            data.update({
                "v": "1.9.5",
                "d": "realme RE879AL1",
                "and": 30,
                "n": "durak.android",
            })
        if self.client.pl == "huawei":
            data = {
                    "command":"c",
                    "pl":"huawei",
                    "p":11,
                    "n":"durak.huawei",
                    "v":"1.0.4",
                    "l":"ru",
                    "d":"HONOR HWKRJ",
                    "tz":"+03:00",
                    "and":29,
                }
        if self.client.pl == "me":
            data = {
                    "command":"c",
                    "p":13,
                    "d":"realme RE879AL1",
                    "v":"1.9.5",
                    "tz":"+03:00",
                    "and":30,
                    "pl":"android",
                    "l":"ru",
                    "n": "durak.android",
                }
        if self.client.pl == "web":
            data = {
                "command":"c",
                    "tz":"+03:00",
                    "t":datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]+"Z",
                    "l":"ru",
                    "p":14,
                    "pl":"web",
                    "d":"web",
                    "v":"1.9.6",
                    "n":"durak.web"
                }
        # print(data)
        self.client.send_server(data)
        return objects.GetSessionKey(self.client.listen()).GetSessionKey

    def sign(self, key: str) -> dict:
        # print("sign2")
        govno="kdusyfngbfydtsttstcnsjsjdflflfl"
        hash = base64.b64encode(hashlib.md5((key+govno).encode()).digest()).decode()
        # hash=  "Nmf+kf1COjrJV6DzxcmITQ=="
        self.client.send_server(
            {
                "command": "sign",
                "hash": hash,
            }
        )
        return self.client.listen()

    def signin_by_access_token(self, token: str) -> int:
        # print("Sign in by token")
        self.client.token = token
        self.client.send_server(
            {
                "command": "auth",
                "token": self.client.token,
            }
        )
        authorized = self.client._get_data("authorized")
        if authorized["command"] == "err":
            raise objects.Err(authorized)
        self.client.uid = authorized["id"]
        self.client.logger.debug(f"{self.client.tag}: Success auth")
        data = self.client._get_data("uu")
        while data["k"] != "dtfp":

            if data.get("v"):
                self.client.info[data["k"]] = data["v"]
            data = self.client._get_data("uu")
        return authorized["id"]

    def huawei_auth(self, id_token: str) -> dict:
        # print("Huawei auth")
        self.client.send_server(
            {
                "command": "huawei_auth",
                "id_token": id_token,
            }
        )
        return self.client.listen(force=True)

    def google_auth(self, id_token: str) -> dict:
        # print("Google auth")
        self.client.send_server(
            {
                "command": "durak_google_auth",
                "id_token": id_token,
            }
        )
        return self.client.listen()

    def get_captcha(self) -> dict:
        # print("Get captcha")
        self.client.send_server(
            {
                "command": "get_captcha",
            }
        )
        return self.client._get_data("captcha")

    def register(self, name, captcha: str = '') -> objects.Register:
        self.client.send_server(
            {
                "command": "register",
                "name": name,
                "captcha": captcha,
            }
        )
        return objects.Register(self.client._get_data("set_token")).Register